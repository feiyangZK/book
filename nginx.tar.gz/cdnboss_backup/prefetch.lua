local template = require 'resty.template'
local c = require 'cdnboss.common'

-- adding pattern
local pattern = template.compile([[
<?xml version="1.0" encoding="UTF-8"?>
<ccsc>
  {% for _, file in ipairs(files) do %}
  <item_id value="{*file.id*}___{*callback*}">
    <source_path>{*file.url*}</source_path>
    <md5>{*file.md5*}</md5>
    <version>{*file.version*}</version>
  </item_id>
  {% end %}
</ccsc>
]], 'no-cache', true)

local function build_operate_request(params)
    local url = c.build_url{
        scheme = 'http',
        host = PREFETCH_OPERATE_HOST,
        port = PREFETCH_OPERATE_PORT,
        path = PREFETCH_OPERATE_PATH,
        query = {
            user = params.user,
            prop = params.prop,
            gslbdomain = params.gslbdomain,
            bussid = params.bussid,
            timeout = params.timeout,
        },
    }

    return c.build_request(url, {
        method = PREFETCH_OPERATE_HTTP_METHOD,
        body = pattern(params),
        headers = {
            host = PREFETCH_OPERATE_HTTP_HOST,
            ['Content-Type'] = 'application/xml';
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end

local function handle_operate(params)
    local req = build_operate_request(params)
    local res, err = c.request_json(req, {
        timeout = PREFETCH_OPERATE_TIMEOUT,
        host = PROXY_HOST,
    })

    local cjson = require "cjson"
    ngx.log(ngx.ERR, "<== res: ".. cjson.encode(res))

    if res ~= nil then
        for i, v in ipairs(res) do
          res[i] = {
            source = v.source,
            filename = v.filename,
          }
        end
    end
  
    ngx.log(ngx.ERR, "==> res: ".. cjson.encode(res))

    return res, err
end

local function build_query_request(params)
    local url = c.build_url{
        scheme = 'http',
        host = PREFETCH_QUERY_HOST,
        port = PREFETCH_QUERY_PORT,
        path = PREFETCH_QUERY_PATH,
        query = {
            file = params.user,
        },
    }
    return c.build_request(url, {
        --method = PREFETCH_OPERATE_HTTP_METHOD,
        method = PREFETCH_QUERY_HTTP_METHOD,
        headers = {
            host = PREFETCH_QUERY_HTTP_HOST,
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end

local function handle_query(params)
    local req = build_query_request(params)
    return c.request_json(req, {
        timeout = PREFETCH_QUERY_TIMEOUT,
        host = PROXY_HOST,
    })
end

local function build_callback_request(params)
    local id, callback = params.outkey:match('(.*)___(.+)')
    local callback_url = ngx.unescape_uri(callback)
    local urlparser = c.parse_url(callback_url)
    local query = urlparser.query
    for k, v in pairs(params) do
      if k == 'percent' then
        query['process'] = v
      end
      query[k] = v
    end

    query.outkey = id

    return c.build_request('/', {
        headers = {
            host = urlparser.host,
            ['Content-Type'] = 'application/javascript';
            ['X-Upstream-Url'] = tostring(urlparser),
        },
    })
end

local function handle_callback(params)
    local req = build_callback_request(params)
    local res, err = c.request(req, {
        timeout = PREFETCH_QUERY_TIMEOUT,
        host = PROXY_HOST,
    })

    if not res then
        return nil, err
    end
    return true
end

local operate = {
    GET = function()
        local params = ngx.req.get_uri_args()
        if params.action == "prefetch" then
            local res, err = handle_query(params)
            if not res then
                c.log_err(err)
            end

            c.write_json{
                errcode = c.examine_http_code(err),
                detail = err or 'OK',
                status = 0,
                process = res and res.percent or 0,
            }
        end
    end,

    POST = function()
        local params = ngx.ctx.params
        if params.action == "prefetch" then
            local res, err = handle_operate(params)
            if not res then
                c.log_err(err)
            end

            c.write_json{
                errcode = c.examine_http_code(err),
                detail = err or 'OK',
                results = res,
            }
        end
    end,
}

return {
    exec = function()
        return operate[ngx.var.request_method]()
    end,

    callback = function()
        local res, err = handle_callback(ngx.req.get_uri_args())
        if not res then
            c.log_err(err)
        end
        return ngx.exit(c.examine_http_code(err))
    end
}

local c = require 'cdnboss.common'
local cjson = require "cjson.safe"

local _M = {}

local AccessKey = "JpxijYcFBxiWpdMIBGyyGbBlzTZDOAJwN1JRtnX8"

function _M.build_prefetch_request(params)
    
    if not params or type(params) ~= "table" then
        return nil
    end

    if not params.files or type(params.files) ~= "table" then 
        return nil
    end
    
    local postdata = {urls={}}
    for _, v in pairs(params.files) do
        if v.url ~= "" then
            table.insert(postdata.urls,v.url)
        end
    end 

    if table.maxn(postdata.urls) == 0 then
        return nil        
    end    

    local url = c.build_url{
        scheme = 'http',
        host = "fusion.qiniuapi.com",
        path = "/v2/tune/prefetch",
    }

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)    

    return c.build_request(url, {
        method = 'POST',
        body = postbody,
        headers = {
            host = "fusion.qiniuapi.com",
	    ['authorization'] = "QBox ".. AccessKey ..":" .. "_ElwXaxUcNRlWYupUoIJSkGo1A4=",
            ['content-type'] = "application/json", 
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end

function _M.prefetch()
    local req = _M.build_prefetch_request(ngx.ctx.params)
    if not req then
        ngx.log(ngx.ERR, "build 3rd_qiniu request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400 ngx.say("3rd_qiniu prefetch failed") return end     
    local dres = cjson.decode(res)
    if tonumber(dres["code"]) ~= 200 then
        ngx.status = 400
    end
    
    ngx.say(res)
end

function _M.build_refresh_request()

    local urls = {}
    local body = c.read_body()
    if body then
        body = string.gsub(body, "\r\n","\n")
        local urlArry = c.string_split(body,'\n')
        for _,url in pairs(urlArry) do
            if url ~= "" then
                table.insert(urls,url)
            end
        end
    end

    if table.maxn(urls) == 0 then
        return nil        
    end    
       
    local postdata={}
    local args = ngx.req.get_uri_args()
    if tonumber(args["type"]) == 0 then
        postdata["urls"] = urls
    elseif tonumber(args["type"]) == 1 then
        postdata["dirs"] = urls
    end 
 
    local url = c.build_url{
        scheme = 'http',
        host = "fusion.qiniuapi.com",
        path = "/v2/tune/refresh",
    }

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)

    return c.build_request(url, {
        method = 'POST',
        body = postbody,
        headers = {
            host = "fusion.qiniuapi.com",
	    ['authorization'] = "QBox ".. AccessKey ..":" .. "kIQ6Y78BGej7DD41BRbbNWT3-cU=",
            ['content-type'] = "application/json", 
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.refresh()
    local req = _M.build_refresh_request()
    if not req then
        ngx.log(ngx.ERR, "build 3rd_qiniu refresh request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400 ngx.say("3rd_qiniu refresh failed") return end     
    local dres = cjson.decode(res)
    if tonumber(dres["code"]) ~= 200 then
        ngx.status = 400
    end
    ngx.say(res)
end


function _M.exec()
    local action = ngx.ctx.action
    
    if action == "prefetch" then
        return _M.prefetch()    
    elseif action == "refresh" then
        return _M.refresh()
    end
    
end

return _M


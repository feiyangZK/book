local c = require 'cdnboss.common'
local cjson = require "cjson.safe"

local _M = {}

--local PROXY_HOST = 'unix://var/tmp/proxy.sock'

local UserName = "leshi_cdn"
local SecretKey = "8427a48b95a8354fc8ae8764de34213a"

function _M.build_prefetch_request(params)
    
    if not params or type(params) ~= "table" then
        return nil
    end

    if not params.files or type(params.files) ~= "table" then 
        return nil
    end
    
    local postdata = {publish_urls={}}
    for _, v in pairs(params.files) do
        if v.url ~= "" then
            table.insert(postdata.publish_urls,v.url)
        end
    end 

    if table.maxn(postdata.publish_urls) == 0 then
        return nil        
    end    

    local date = os.date("%Y%m%d")    
    local digest = ngx.md5(date .. UserName .. SecretKey)

    postdata["signature"] = digest
    postdata["username"] = UserName

    local url = c.build_url{
        scheme = 'http',
        host = "opencdn.jcloud.com",
        port = 80,
        path = "/api/prefetch",
    }

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)    

    return c.build_request(url, {
        method = 'POST',
        body = postbody,
        headers = {
            host = "opencdn.jcloud.com",
            ['content-type'] = "application/json", 
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.prefetch()
    local req = _M.build_prefetch_request(ngx.ctx.params)
    if not req then
        ngx.log(ngx.ERR, "build 3rd_jdcloud request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400 ngx.say("3rd_jdcloud prefetch failed") return end     
    local find = string.find(res, "\"status\":0")
    if not find then ngx.status = 400 ngx.say(res) return end   
    
    ngx.say(res)
end


function _M.build_refresh_request()

    local postdata = {instances={}}
    local body = c.read_body()
    if body then
        body = string.gsub(body, "\r\n","\n")
        local urlArry = c.string_split(body,'\n')
        for k,url in pairs(urlArry) do
            if url ~= "" then
                table.insert(postdata.instances,url)
            end
        end
    end

    if table.maxn(postdata.instances) == 0 then
        return nil        
    end    
       
    local date = os.date("%Y%m%d")    
    local digest = ngx.md5(date .. UserName .. SecretKey)

    postdata["signature"] = digest
    postdata["username"] = UserName
 
    local args = ngx.req.get_uri_args()
    if tonumber(args["type"]) == 0 then
        postdata["type"] = "file"
    elseif tonumber(args["type"]) == 1 then
        postdata["type"] = "dir"
    end 
 
    local url = c.build_url{
        scheme = 'http',
        host = "opencdn.jcloud.com",
        port = 80,
        path = "/api/refresh",
    }

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)

    return c.build_request(url, {
        method = 'POST',
        body = postbody,
        headers = {
            host = "opencdn.jcloud.com",
            ['content-type'] = "application/json", 
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.refresh()
    local req = _M.build_refresh_request()
    if not req then
        ngx.log(ngx.ERR, "build 3rd_jdcloud refresh request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400 ngx.say("3rd_jdcloud refresh failed") return end     
    local find = string.find(res, "\"status\":0")
    if not find then ngx.status = 400 ngx.say(res) return end   
    
    ngx.say(res)
end


function _M.exec()
    local action = ngx.ctx.action
    
    if action == "prefetch" then
        return _M.prefetch()    
    elseif action == "refresh" then
        return _M.refresh()
    end
    
end

return _M



local cjson = require('cjson.safe')

local _M = {}

function _M.exec()

    ngx.req.read_body()
    ngx.ctx.action = "refresh"

    local res_dnion, res_jdcloud,res_baishan,res_qiniu = ngx.location.capture_multi {
        {"/3rd_dnion",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_jdcloud",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_baishan",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_qiniu",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
    }

    if res_dnion.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_dnion refresh failed ")
    end

    if res_jdcloud.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_jdcloud refresh failed ")
    end

    if res_baishan.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_baishan refresh failed ")
    end

    if res_qiniu.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_qiniu refresh failed ")
    end

end


return _M 

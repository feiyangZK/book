local http = require "resty.http"
local cjson = require('cjson.safe')
local c = require ('cdnboss.common')

local _M = {}

local function notice_refresh(premature, req_uri, postbody)

    if not premature then
        local httpc = http.new()
        httpc:set_timeout(5000)

        local res, err = httpc:request_uri(req_uri, {
            method = "POST",
            body   = postbody,
            headers = { 
                ["Host"]="cms.cdnboss.lecloud.com",
                ["Content-Type"] = "application/x-www-form-urlencoded",
             }   
        })  

        if not res then
            ngx.log(ngx.ERR, "Connect to [ " .. req_uri .. " ] Error !" .. tostring(err)) 
            return 
        end 

        if (res.status ~= 200 and res.status ~= 206) then
            ngx.log(ngx.ERR, "postRefresh failed,status:" .. res.status)
            return
        end

        ngx.log(ngx.ERR, "Test OK")
    end
end

local function otherCdnRefresh(delay)

    local body = c.read_body()	
    if body then
  	local args = ngx.req.get_uri_args()

        local query = ""
        for key, val in pairs(args) do
            if query ~= "" then
                query = query .. "&" .. key .. "=" .. val
            else
                query = key .. "=" .. val
            end
        end

	local req_uri = "http://127.0.0.1:8080/3rd_cdn/refresh"

        if query ~= "" then
            req_uri = req_uri .. "?" .. query
        end			
	
    	local ok, err = ngx.timer.at(delay, notice_refresh, req_uri, body)
    end
end

function _M.exec()

    ngx.req.read_body()
    ngx.ctx.action = "refresh"

    local res_letv = ngx.location.capture_multi {
        {"/letv_refresh",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
    }

    if res_letv.status ~= ngx.HTTP_OK then
	ngx.log(ngx.ERR, "Fusion ===> letv refresh failed ")
    end
	
    ngx.say(res_letv.body)
     
    otherCdnRefresh(120)	

end


return _M 

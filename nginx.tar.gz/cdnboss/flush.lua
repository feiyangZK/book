local template = require 'resty.template'
local c = require 'cdnboss.common'
local encode_base64 = ngx.encode_base64
local unescape_uri = ngx.unescape_uri

-- adding pattern
local pattern = template.compile([[{% for _, file in ipairs(files) do %}{*file.url*}\r\n{% end %}]], 'no-cache', true)

local function build_operate_request(params)
    local url = c.build_url{
        scheme = 'http',
        host = FLUSH_OPERATE_HOST,
        port = FLUSH_OPERATE_PORT,
        path = FLUSH_OPERATE_PATH,
        query = {
            access = params.access,
            user = params.user,
            type = params.filetype,
            cdnType = params.cdntype,
            callback = encode_base64(CALLBACK_URL_PREFIX .. params.callback),
        },
    }

    return c.build_request(url, {
        method = FLUSH_OPERATE_HTTP_METHOD,
        body = pattern(params),
        headers = {
            host = FLUSH_OPERATE_HTTP_HOST,
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end

local function handle_operate(params)
    local req = build_operate_request(params)
    local res, err = c.request_json(req, {
        timeout = FLUSH_OPERATE_TIMEOUT,
        host = PROXY_HOST,
    })

    if not res then
        return nil, err
    elseif res.errorCode ~= 0 then
        return nil, res.detail or 'failure'
    end

    return res
end

local function build_query_request(params)
    local url = c.build_url{
        scheme = 'http',
        host = FLUSH_QUERY_HOST,
        port = FLUSH_QUERY_PORT,
        path = FLUSH_QUERY_PATH,
        query = {
            id = params.id,
            user = params.user,
            cdnType = params.cdntype,
        },
    }
    return c.build_request(url, {
        method = FLUSH_OPERATE_HTTP_METHOD,
        headers = {
            host = FLUSH_QUERY_HTTP_HOST,
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end

local function handle_query(params)
    local req = build_query_request(params)
    local res, err = c.request_json(req, {
        timeout = FLUSH_QUERY_TIMEOUT,
        host = PROXY_HOST,
    })

    if not res then
        return nil, err
    elseif res.errorCode ~= 0 then
        return nil, res.detail or 'failure'
    end

    return res
end

local function build_callback_request(params)
    local id, callback = params.outkey:match('(.*)___(.+)')
    local callback_url = unescape_uri(callback)
    local urlparser = c.parse_url(callback_url)
    local query = urlparser.query
    for k, v in pairs(params) do
      query[k] = v
    end

    query.outkey = id

    return c.build_request('/', {
        headers = {
            host = urlparser.host,
            ['Content-Type'] = 'application/javascript';
            ['X-Upstream-Url'] = tostring(urlparser),
        },
    })
end

local function handle_callback(params)
    local req = build_callback_request(params)
    local res, err = c.request(req, {
        timeout = FLUSH_QUERY_TIMEOUT,
        host = PROXY_HOST,
    })

    if not res then
        return nil, err
    end
    return true
end

local operate = {
    GET = function()
        local params = ngx.req.get_uri_args()
        if params.action == "flush" then
            local res, err = handle_query(params)
            if not res then
                c.log_err(err)
            end

            local value = res and res.value[1] or nil
            c.write_json{
                errcode = c.examine_http_code(err),
                detail = res and res.detail or err or 'OK',
                status = value and value.status or 0,
                process = value and value.process or 0,
            }
        end
    end,

    POST = function()
        local params = ngx.ctx.params
        if params.action == "flush" then
            local res, err = handle_operate(params)
            if not res then
                c.log_err(err)
            end

            c.write_json{
                errcode = c.examine_http_code(err),
                detail = res and res.detail or err or 'OK',
                id = res and res.id or nil,
            }
        end
    end,
}

return {
    exec = function()
        return operate[ngx.var.request_method]()
    end,
}

local c = require 'cdnboss.common'
local cjson = require 'cjson.safe'

local _M = {}

function _M.build_refresh_request()

    local body = c.read_body()
    if not body or body == "" then return nil end
    	
    local args = ngx.req.get_uri_args()

    local url = c.build_url{
        scheme = 'http',
        host = "purge.cache.lecloud.com",
        --host = "123.59.125.229",
        port = 8080,
        path = "/control/user/purge/add",
        query = {
	    pf = args["pf"],
            type = args["type"],
	    user = args["user"],
	    cdnId = args["cdnId"],
	    access = args["access"],
	    --cdnType = args["cdnType"],
	    cdnType = 3,
	    callback = args["callback"], 
	    cacheLevel = args["cacheLevel"],
        },
    }

    return c.build_request(url, {
        method = 'POST',
	body = body,
        headers = {
            host = "purge.cache.lecloud.com",
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.refresh()
    local req = _M.build_refresh_request()
    if not req then
        ngx.log(ngx.ERR, "build letv refresh request failed")
        return
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })

    if not res then c.log_err(err) ngx.status = 400  ngx.say("letv refresh failed") return end
    local dres = cjson.decode(res)
    if tonumber(dres["errorCode"]) ~= 0 then  
     	ngx.status = 400 ngx.say(res) 
    	return
    end

    ngx.say(res)
end

function _M.exec()
    local action = ngx.ctx.action
    if action == "refresh" then
	return _M.refresh()
    end
end

return _M

local c = require 'cdnboss.common'
local cjson = require "cjson.safe"
local http =  require 'resty.http'

local _M = {}

local Token = "ac2e43d69aaaf48bc7dd8cd73bd9d7eb"

function _M.prefetch()
    
    local params = ngx.ctx.params
    local postdata = {urls={}}
    for _, v in pairs(params.files) do
        if v.url ~= "" then
            table.insert(postdata.urls,v.url)
        end
    end

    if table.maxn(postdata.urls) == 0 then
        return 
    end

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)

    local httpc = http.new()
    httpc:set_timeout(5000)
   
    local req_uri = "http://127.0.0.1/cloud_baishan"	
    local upstream_uri = "https://api.qingcdn.com/v2/cache/prefetch?token=" .. Token
    local res, err = httpc:request_uri(req_uri, {
        method = "POST",
        body = postbody,
        headers = { 
            ["Host"]="cms.cdnboss.lecloud.com",
            ["Content-Type"] = "application/json",
	    ['X-Upstream-Url'] = upstream_uri,
         }   
    })  

    if not res then
        ngx.log(ngx.ERR, "Connect to [ " .. req_uri .. " ] Error !" .. tostring(err)) 
        return 
    end 

    if (res.status ~= 200 and res.status ~= 206) then
        ngx.log(ngx.ERR, "3rd_baishan prefetch failed,status:" .. res.status)
        return
    end	

    local dres = cjson.decode(res.body)
    if tonumber(dres["code"]) ~= 0 then
        ngx.status = 400 ngx.say(res.body)
        return
    end    
	
    ngx.say(res.body)
end


function _M.refresh()

    local postdata = {urls={}}
    local body = c.read_body()
    if body then
        body = string.gsub(body, "\r\n","\n")
        local urlArry = c.string_split(body,'\n')
        for _,url in pairs(urlArry) do
            if url ~= "" then
		table.insert(postdata.urls,url)
            end
        end
    end

    if table.maxn(postdata.urls) == 0 then
        return nil        
    end    
   
    local args = ngx.req.get_uri_args()
    if tonumber(args["type"]) == 0 then
        postdata["type"] = "url"
    elseif tonumber(args["type"]) == 1 then
        postdata["type"] = "dir"
    end

    local postbody = cjson.encode(postdata)
    ngx.log(ngx.ERR, "postbody: " .. postbody)

    local httpc = http.new()
    httpc:set_timeout(5000)

    local req_uri = "http://127.0.0.1/cloud_baishan"
    local upstream_uri = "https://api.qingcdn.com/v2/cache/refresh?token=" .. Token
    local res, err = httpc:request_uri(req_uri, {
        method = "POST",
        body = postbody,
        headers = {
            ["Host"]="cms.cdnboss.lecloud.com",
            ["Content-Type"] = "application/json",
            ['X-Upstream-Url'] = upstream_uri,
         }
    })

    if not res then
        ngx.log(ngx.ERR, "Connect to [ " .. req_uri .. " ] Error !" .. tostring(err))
        return
    end

    if (res.status ~= 200 and res.status ~= 206) then
        ngx.log(ngx.ERR, "3rd_baishan prefetch failed,status:" .. res.status)
        return
    end

    local dres = cjson.decode(res.body)
    if tonumber(dres["code"]) ~= 0 then
        ngx.status = 400 ngx.say(res.body)
        return
    end
	
    ngx.say(res.body)
end


function _M.exec()
    local action = ngx.ctx.action
    
    if action == "prefetch" then
        return _M.prefetch()    
    elseif action == "refresh" then
        return _M.refresh()
    end    
end

return _M


local c = require 'cdnboss.common'
local cjson = require "cjson.safe"

local _M = {}

function _M.build_prefetch_request(params)
    
    if not params or type(params) ~= "table" then
        return nil
    end

    if not params.files or type(params.files) ~= "table" then 
        return nil
    end

    local prefetch_url = ""
    for _, v in pairs(params.files) do
        if prefetch_url ~= "" then
            prefetch_url = prefetch_url .. "," .. v.url          
        else
            prefetch_url = v.url
        end
    end 

    if prefetch_url == "" then
        return nil        
    end    
 
    local url = c.build_url{
        scheme = 'http',
        host = "push.dnion.com",
        port = 80,
        path = "/preCache.do",
        query = {
            captcha = "436bdabb",
            url = prefetch_url,
        },
    }

    return c.build_request(url, {
        method = 'GET',
        headers = {
            host = "push.dnion.com",
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.prefetch()
    local req = _M.build_prefetch_request(ngx.ctx.params)
    if not req then
        ngx.log(ngx.ERR, "build 3rd_dnion request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400 ngx.say("dnion prefetch failed") return end     
    local find = string.find(res, "<code>200</code>")
    if not find then ngx.status = 400  ngx.say(res) return end   
   
    ngx.say(res)
end


function _M.build_refresh_request()

    local refresh_url = ""
    local body = c.read_body()
    if body then
        body = string.gsub(body, "\r\n","\n")
        local urlArry = c.string_split(body,'\n')
        for k,url in pairs(urlArry) do
            if url ~= "" then
                if refresh_url ~= "" then
                    refresh_url = refresh_url .. "," .. url
                else
                    refresh_url = url
                end
            end
        end
    end

    if refresh_url == "" then
        return nil        
    end    
    
    local args = ngx.req.get_uri_args()
    ngx.log(ngx.ERR, "refresh_url: " .. refresh_url)
 
    local url = c.build_url{
        scheme = 'http',
        host = "push.dnion.com",
        port = 80,
        path = "/cdnUrlPush.do",
        query = {
            captcha = "436bdabb",
            url = refresh_url,
            type = args["type"]
        },
    }

    return c.build_request(url, {
        method = 'GET',
        headers = {
            host = "push.dnion.com",
            ['X-Upstream-Url'] = tostring(url),
        },
    })
end


function _M.refresh()
    local req = _M.build_refresh_request()
    if not req then
        ngx.log(ngx.ERR, "build 3rd_dnion refresh request failed")
        return 
    end

    local res,err = c.request(req, {
        timeout = 5000,
        host = PROXY_HOST,
    })
     
    if not res then c.log_err(err) ngx.status = 400  ngx.say("dnion refresh failed") return end     
    local find = string.find(res, "<code>200</code>")
    if not find then ngx.status = 400 ngx.say(res) return end   
	
    ngx.say(res)
end


function _M.exec()
    local action = ngx.ctx.action
    
    if action == "prefetch" then
        return _M.prefetch()    
    elseif action == "refresh" then
        return _M.refresh()
    end    
end

return _M


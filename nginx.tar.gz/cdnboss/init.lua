-- init.lua
-- global configure

PREFETCH_OPERATE_TIMEOUT = 5000
PREFETCH_OPERATE_HOST = 'mcache.oss.letv.com'
PREFETCH_OPERATE_PORT = 80
PREFETCH_OPERATE_PATH = '/ext/atsfile'
PREFETCH_OPERATE_HTTP_HOST = 'mcache.oss.letv.com'
PREFETCH_OPERATE_HTTP_METHOD = 'POST'

PREFETCH_QUERY_TIMEOUT = 5000
PREFETCH_QUERY_HOST = 'mcache.oss.letv.com'
PREFETCH_QUERY_PORT = 80
PREFETCH_QUERY_PATH = '/ext/percent'
PREFETCH_QUERY_HTTP_HOST = 'mcache.oss.letv.com'
PREFETCH_QUERY_HTTP_METHOD = 'GET'

FLUSH_OPERATE_TIMEOUT = 5000
FLUSH_OPERATE_HOST = 'control.cache.lecloud.com'
FLUSH_OPERATE_PORT = 8080
FLUSH_OPERATE_PATH = '/control/user/purge/add'
FLUSH_OPERATE_HTTP_HOST = 'control.cache.lecloud.com'
FLUSH_OPERATE_HTTP_METHOD = 'POST'

FLUSH_QUERY_TIMEOUT = 5000
FLUSH_QUERY_HOST = 'mca.cache.lecloud.com'
FLUSH_QUERY_PORT = 8080
FLUSH_QUERY_PATH = '/control/user/purge/query'
FLUSH_QUERY_HTTP_HOST = 'mca.cache.lecloud.com'
FLUSH_QUERY_HTTP_METHOD = 'GET'

PROXY_HOST = 'unix://var/tmp/proxy.sock'

CALLBACK_ARG = 'origin'
CALLBACK_URL_PREFIX = 'http://cms.cdnboos.lecloud.com/cms/callback?' .. CALLBACK_ARG .. '='

-- TODO: combine codes from flush.lua and prefetch.lua

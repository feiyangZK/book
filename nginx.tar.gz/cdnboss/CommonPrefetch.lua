local cjson = require('cjson.safe')

local _M = {}

function _M.exec()

    ngx.ctx.action = "prefetch"

    local res_dnion, res_jdcloud,res_baishan,res_qiniu,res_letv = ngx.location.capture_multi {
        {"/3rd_dnion",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_jdcloud",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_baishan",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/3rd_qiniu",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
        {"/letv_prefetch",{always_forward_body=true,args=ngx.req.get_uri_args(),ctx = ngx.ctx}},
    }

    --local result = ""
    --local res={errcode=200}
    if res_dnion.status ~= ngx.HTTP_OK then
        --res.errcode = 400
        --result = "3rd_dnion failed, "
        ngx.log(ngx.ERR, "Fusion ===> 3rd_dnion failed ")
    end

    if res_jdcloud.status ~= ngx.HTTP_OK then
        --res.errcode = 400
        --result = result .. "3rd_jdcloud failed, "
        ngx.log(ngx.ERR, "Fusion ===> 3rd_jdcloud failed ")
    end

    if res_baishan.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_baishan failed ")
    end

    if res_qiniu.status ~= ngx.HTTP_OK then
        ngx.log(ngx.ERR, "Fusion ===> 3rd_qiniu failed ")
    end

    if res_letv.status ~= ngx.HTTP_OK then
        --res.errcode = 400
        --result = result .. "letv_prefetch failed, "
        ngx.log(ngx.ERR, "Fusion ===> letv_prefetch failed")
    end
  
    ngx.say(res_letv.body)
	
    --[[
    if res_dnion.status == ngx.HTTP_OK and res_jdcloud.status == ngx.HTTP_OK and res_letv.status == ngx.HTTP_OK then
        --ngx.say("test ===> 3rd prefetch ok ")  
        ngx.say(res_letv.body)
        return
    end

    res["result"]=result
    ngx.log(ngx.ERR, "result: ".. result)
    ngx.say(cjson.encode(res))
    ]]
end


return _M


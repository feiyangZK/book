local cjson = require "cjson"
local http = require "resty.http"
local http_headers = require "resty.http_headers"
local ffi = require "ffi"
local bit = require "bit"
local stock = require "cdnboss.stock"

local ngx = ngx
local ngx_now = ngx.now
local ngx_log = ngx.log
local ngx_req = ngx.req
local ngx_re_match = ngx.re.match
local ngx_encode_args = ngx.encode_args
local ngx_decode_args = ngx.decode_args
local ngx_req_get_headers = ngx_req.get_headers
local tonumber = tonumber
local concat = table.concat
local int = math.floor
local type = type
local pairs = pairs
local ipairs = ipairs
local format = string.format
local match = string.match
local sub = string.sub
local gsub = string.gsub
local find = string.find
local json_null = cjson.null
local setmetatable = setmetatable
local pcall = pcall


local ngx_req = ngx.req
local io_open = io.open
local os_rename = os.rename
local APP = APP
local TMP_HOME = '/var/tmp'

local M = {}

local DEFAULT_HEADERS = {}
local DISCARD_HEADERS = {
    'Proxy-Connection',
    'Content-Type',
    'Content-Length',
    'Accept',
    'Accept-Encoding',
    'Cookie',
}

M.PARAM_DEL = '-[-delete-]-'

--
-- loggings
--

local NGX_DEBUG = ngx.DEBUG
local NGX_INFO = ngx.INFO
local NGX_WARN = ngx.WARN
local NGX_ERR = ngx.ERR

function M.log_debug(...)
    return ngx_log(NGX_DEBUG, ...)
end

function M.log_debugf(s, ...)
    return M.log_debug(format(s, ...))
end

function M.log_info(...)
    return ngx_log(NGX_INFO, ...)
end

function M.log_infof(s, ...)
    return M.log_info(format(s, ...))
end

function M.log_warn(...)
    return ngx_log(NGX_WARN, ...)
end

function M.log_warnf(s, ...)
    return M.log_warn(format(s, ...))
end

function M.log_err(...)
    return ngx_log(NGX_ERR, ...)
end

function M.log_errf(s, ...)
    return M.log_err(format(s, ...))
end

function M.string_split(str, delimiter)
    local words = {}
    local num = 1 
    local init_index = 1 
    local start_idx = 0 
    local end_idx = 0 
    while true do
        start_idx, end_idx = string.find(str, delimiter, init_index)
        if not start_idx then
            words[num] = string.sub(str, init_index)
            break
        end 
        words[num] = string.sub(str, init_index, start_idx - 1)
        init_index = end_idx + 1 
        num = num + 1 
    end 
    return words
end

--
-- utilities
--

ffi.cdef [[
    typedef long time_t;
    time_t mktime(void *tm);
    struct tm * localtime(const time_t *clock);
    struct tm * gmtime(const time_t *clock);
    size_t strftime(char *restrict s, size_t maxsize,
                    const char *restrict format,
                    const struct tm *restrict timeptr);
    char * strptime(const char *s,
                    const char *format,
                    void *tm);

    typedef uint32_t in_addr_t;
    in_addr_t inet_addr(const char *cp);
    uint32_t ntohl(uint32_t netlong);
]]


local NULL = ffi.null
local ffi_new = ffi.new
local ffi_copy = ffi.copy
local ffi_string = ffi.string
local c_mktime = ffi.C.mktime
local c_localtime = ffi.C.localtime
local c_gmtime = ffi.C.gmtime
local c_strftime = ffi.C.strftime
local c_strptime = ffi.C.strptime

function M.now()
    return int(ngx_now())
end

function M.strftime(t, fmt, maxsize, gmt)
    t = t or M.now()
    fmt = fmt or '%Y-%m-%dT%H:%M:%S%z'
    maxsize = maxsize or 32

    local xtime = gmt and c_gmtime or c_localtime
    local s = ffi_new('char[?]', maxsize)
    local tm = xtime(ffi_new('time_t[1]', t))
    local ret = c_strftime(s, maxsize, fmt, tm)
    if ret > 0 then
        return ffi_string(s, ret)
    end

    return nil
end

function M.strptime(s, fmt)
    if s then
        fmt = fmt or "%a, %d %b %Y %H:%M:%S %Z"
        local tm = ffi_new('int[?]', 16)
        local p = c_strptime(s, fmt, tm)
        if p == NULL then
            return nil
        end

        return tonumber(c_mktime(tm))
    end
end

function M.is_trivial(x)
    return x == nil or #x == 0
end

function M.null_then(x, defval)
    if x == nil or x == json_null then
        return defval
    end

    return x
end

function M.parse_query(query)
    if not query then
        return {}
    end

    local ctx = ngx.ctx
    local key = query .. '@QueryParser'
    local cached = ctx[key]
    local m = cached

    if not m then
        m = ngx_decode_args(query) or {}
        ctx[key] = m
    end

    local tb = {}
    for k, v in pairs(m) do
        if type(v) == 'table' then
            v = v[1]
        end
        tb[k] = v
    end
    return tb
end

function M.build_url(self, without)
    local scheme = self.scheme
    local user = self.user
    local pass = self.pass
    local host = self.host
    local port = self.port
    local path = self.path
    local query = self.query
    local fragment = self.fragment

    local s, n = {}, 0
    without = without or {}

    if scheme and not without.scheme then
        n = n + 1
        s[n] = scheme .. '://'
    end

    if user and not without.user then
        n = n + 1
        s[n] = user
    end

    if pass and not without.pass then
        n = n + 1
        s[n] = ':' .. pass
    end

    if user and not without.user then
        n = n + 1
        s[n] = '@'
    end

    if host and not without.host then
        n = n + 1
        s[n] = host
    end

    if port and tonumber(port) ~= 80 and not without.port then
        n = n + 1
        s[n] = ':' .. port
    end

    if path and not without.path then
        if path:sub(1, 1) ~= '/' then
            path = '/' .. path
        end

        n = n + 1
        s[n] = path
    end

    if query and not without.query then
        if type(query) == 'table' then
            query = ngx_encode_args(query)
        end
        n = n + 1
        s[n] = '?' .. query
    end

    if fragment and not without.fragment then
        n = n + 1
        s[n] = '#' .. fragment
    end

    return concat(s)
end

function M.parse_url(url)
    local ctx = ngx.ctx
    local key = url .. '@UrlParser'
    local cached = ctx[key]
    local m = cached

    if not m then
        m = ngx_re_match(url, [[^(?:(.*)://(?:([^:/]*)(?::([^/]*))?@)?([^:/?#]+)?(?::(\d+))?)?([^?#]*)?(?:\?([^#]*))?(?:#(.*))?]],
            "jo") or {}
        ctx[key] = m
    end

    local self = {}
    if m then
        self.scheme = m[1]
        self.user = m[2]
        self.pass = m[3]
        self.host = m[4]
        self.port = tonumber(m[5])
        self.path = m[6]
        self.query = M.parse_query(m[7])
        self.fragment = m[8]
    end

    return setmetatable(self, { __tostring = M.build_url })
end

function M.extend_table(query, ...)
    local tb = { ... }
    for i = 1, #tb do
        local t = tb[i]
        for k, v in pairs(t) do
            if v == M.PARAM_DEL then
                query[k] = nil
            else
                query[k] = v
            end
        end
    end

    return query
end

local function get_nginx_headers()
    local ok, res = pcall(ngx_req_get_headers)
    local headers = M.extend_table(http_headers.new(), ok and res or {})
    for _, h in ipairs(DISCARD_HEADERS) do
        headers[h] = nil
    end
    return headers
end

function M.build_request(urlparser, opts)
    if type(urlparser) == 'string' then
        urlparser = M.parse_url(urlparser)
    end

    local path = urlparser.path or '/'
    local headers = M.extend_table(get_nginx_headers(), DEFAULT_HEADERS)

    local method, version, curr_headers, body, ssl_verify

    if opts then
        method = opts.method
        version = opts.version
        curr_headers = opts.headers
        body = opts.body
        ssl_verify = opts.ssl_verify
    end

    if path:sub(1, 1) ~= '/' then
        path = '/' .. path
    end

    if curr_headers then
        M.extend_table(headers, curr_headers)
    end

    return {
        version = version or 1.1,
        method = method,
        path = path,
        query = urlparser.query,
        headers = headers,
        body = body,
        ssl_verify = ssl_verify,
    }
end

function M.request(req, opts)
    local httpc = http.new()
    httpc:set_timeout(opts.timeout)

    local ok, err
    if opts.host:sub(1, 5) == 'unix:' then
        ok, err = httpc:connect(opts.host)
    else
        ok, err = httpc:connect(opts.host, opts.port)
    end
    if not ok then
        return nil, err
    end

    local res, err = httpc:request(req)
    if not res then
        return nil, err
    end

    if res.status ~= 200 then
        local err = 'http code ' .. res.status
        if res.has_body then
            err = err .. '\n' .. res:read_body()
        end
        return nil, err
    end

    if res.headers['Content-Type']:find('gzip') then
        return nil, 'Unsupported gzip response, advise requesting via proxy_pass with gunzip on'
    end

    return res:read_body()
end

function M.request_json(req, opts)
    local body, err = M.request(req, opts)
    if not body then
        return nil, err
    end

    return cjson.decode(body)
end

function M.parse_filext(filename, sep)
    sep = sep or '%.'
    return match(filename, ".*" .. sep .. "(.-)$")
end

function M.replace_filext(filename, filext)
    return gsub(filename, "^(.*)%.(.-)$", "%1." .. filext)
end

function M.has_prefix(s, prefix)
    prefix = prefix or ''
    return sub(s, 1, #prefix) == prefix
end

function M.has_postfix(s, postfix)
    postfix = postfix or ''
    return sub(s, -#postfix) == postfix
end

function M.ip_to_integer(ip)
    if M.is_trivial(ip) then
        return 0
    end

    return ffi.C.ntohl(ffi.C.inet_addr(ip))
end

function M.integer_to_ip(integer)
    if not integer or integer < 1 then
        return '0.0.0.0'
    end

    local d = bit.band(integer, 0xFF)
    local c = bit.band(bit.rshift(integer, 8), 0xFF)
    local b = bit.band(bit.rshift(integer, 16), 0xFF)
    local a = bit.band(bit.rshift(integer, 24), 0xFF)
    return format("%d.%d.%d.%d", a, b, c, d)
end

function M.examine_http_code(err)
    if M.is_trivial(err) then
        return 200
    end

    if find(err, "time") then
        return 504
    elseif find(err, "refuse") then
        return 502
    end

    return 500
end

function M.read_body()
    ngx_req.read_body()
    local body = ngx_req.get_body_data()
    if not body then
        local body_file = ngx_req.get_body_file()
        if body_file then
            local fp = io_open(body_file, 'rb')
            if fp then
                body = fp:read("*all")
            end
        end
    end

    return body
end

function M.read_json(url_decode)
    local body = M.read_body()
    if body and url_decode then
        body = ngx.unescape_uri(body)
    end
    return body and cjson.decode(body)
end

function M.write_json(data)
    ngx.header['Content-Type'] = 'application/javascript'
    ngx.say(cjson.encode(data))
    --ngx.log(ngx.ERR, "write_json: "..cjson.encode(data))
end

function M.marshal(value, encode)
    if value and encode then
        local ok, res = pcall(encode, value)
        if ok then
            value = res
        else
            return nil, res
        end
    end

    return value
end

function M.unmarshal(value, decode)
    if value and decode then
        local ok, res = pcall(decode, value)
        if ok then
            value = res
        else
            return nil, res
        end
    end

    return value
end

function M.persist(key, value, encode)
    if M.is_trivial(key) or not value then
        return
    end

    key = format('%s_%s', APP, key)
    stock[key] = value

    local err
    value, err = M.marshal(value, encode)
    if not value then
        M.log_err(err)
        return
    end

    local cache = ngx.shared.cache
    cache:set(key, value)

    local path = TMP_HOME .. '/' .. key
    local path_swp = format('%s.%s', path, ngx.worker.pid())

    local fp, err = io_open(path_swp, 'wb')
    if not fp then
        M.log_err(err)
        return
    end

    local ok, err = fp:write(value)
    if not ok then
        M.log_err(err)
        return
    end

    fp:close()
    ok, err = os_rename(path_swp, path)
    if not ok then
        M.log_err(err)
        return
    end
end

function M.recover(key, decode)
    if M.is_trivial(key) then
        return
    end

    key = format('%s_%s', APP, key)
    local value, err = stock[key]

    local cache = ngx.shared.cache
    if not value then
        value, err = M.unmarshal(cache:get(key), decode)

        if not value then
            local fp = io_open(TMP_HOME .. '/' .. key, 'rb')
            if fp then
                local data = fp:read("*all")
                if data then
                    cache:set(key, data)
                    value, err = M.unmarshal(data, decode)
                end
            end
        end

        if value and value ~= stock[key] then
            stock[key] = value
        end
    end

    if not err then
        M.log_err(err)
    end

    return value
end

--
-- class, see http://lua-users.org/wiki/ObjectOrientationTutorial
--

function M.inherit(...)
    -- "cls" is the new class
    local cls, bases = {}, { ... }
    -- copy base class contents into the new class
    for _, base in ipairs(bases) do
        for k, v in pairs(base) do
            cls[k] = v
        end
    end
    -- set the class's __index, and start filling an "is_a" table that contains this class and all of its bases
    -- so you can do an "instance of" check using my_instance.is_a[MyClass]
    cls.__index, cls.is_a = cls, { [cls] = true }
    for _, base in ipairs(bases) do
        for c in pairs(base.is_a or {}) do
            cls.is_a[c] = true
        end
        cls.is_a[base] = true
    end
    -- the class's __call metamethod
    setmetatable(cls, {
        __call = function(c, ...)
            local instance = setmetatable({}, c)
            -- run the init method if it's there
            local init = instance._init
            if init then
                init(instance, ...)
            end
            return instance
        end
    })
    -- return the new class table, that's ready to fill with methods
    return cls
end

return M

